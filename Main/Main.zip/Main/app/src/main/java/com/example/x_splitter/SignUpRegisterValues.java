//package com.example.x_splitter;
//
//public class SignUpRegisterValues{
//    String email;
//    String username;
//    String password;
//}
