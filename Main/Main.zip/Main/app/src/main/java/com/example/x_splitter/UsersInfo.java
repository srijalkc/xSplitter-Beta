package com.example.x_splitter;

public class UsersInfo {
    String email, username;

    public UsersInfo() {
        //empty constructor for reading value
    }

    public UsersInfo(String email, String username) {
        this.email = email;
        this.username = username;
    }
}
