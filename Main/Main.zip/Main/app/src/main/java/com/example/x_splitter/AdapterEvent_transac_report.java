package com.example.x_splitter;

public class AdapterEvent_transac_report {
}
